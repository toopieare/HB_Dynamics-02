#!/bin/bash

execstack -s ./cstarget
chmod +x ./cstarget
cp ./cstarget /tmp/